"""
Main community model
"""

from mesa import Model
from mesa.time import RandomActivation
from src.agents import CommunityAgent
from src.deliberation import CommunityDeliberation
from src.utils import logger

class CommunityModel(Model):
    """Community ABM"""
    
    def __init__(self, n_agents=3, culture_type="collectivism"):
        super().__init__()
        
        self.n_agents = n_agents
        self.culture_type = culture_type
        self.schedule = RandomActivation(self)
        
        # Create agents
        for i in range(n_agents):
            agent = CommunityAgent(
                unique_id=i,
                model=self,
                culture=culture_type
            )
            self.schedule.add(agent)
        
        logger.info(f"Model initialized: {n_agents} {culture_type} agents")
    
    def trigger_governance_event(self, event_type="wrongful_arrest"):
        """Trigger a governance event"""
        
        # Define the event
        if event_type == "wrongful_arrest":
            event = {
                'type': 'wrongful_arrest',
                'description': """
A respected community member was mistakenly arrested by police 
yesterday evening. The person was detained for 3 hours before 
the error was discovered and they were released. The arrest 
occurred in front of neighbors.
                """.strip()
            }
        else:
            event = {
                'type': 'generic',
                'description': 'A governance issue occurred.'
            }
        
        logger.info(f"Event triggered: {event_type}")
        
        return event
    
    def generate_institution_response(self, response_type="blaming"):
        """Generate institution's response to the event"""
        
        if response_type == "blaming":
            response = {
                'type': 'blaming',
                'text': """
The police department states that the arrest was made based on 
a tip from a community member. The department followed proper 
procedures. The public should ensure they provide accurate 
information when reporting suspicious activities. The department 
is not at fault in this case.
                """.strip()
            }
        
        elif response_type == "procedural_justice":
            response = {
                'type': 'procedural_justice',
                'text': """
The police department acknowledges that a mistake was made in 
this arrest. We sincerely apologize to the individual and their 
family for the distress caused. We have reviewed our procedures 
and will implement additional verification steps to prevent 
similar errors. We value the community's trust and are committed 
to transparent, fair policing.
                """.strip()
            }
        
        else:
            response = {
                'type': 'neutral',
                'text': 'The institution has been notified.'
            }
        
        logger.info(f"Institution response: {response_type}")
        
        return response
    
    def run_deliberation(self, event_type="wrongful_arrest", 
                         response_type="blaming"):
        """Run a community deliberation"""
        
        # Generate event and response
        event = self.trigger_governance_event(event_type)
        institution_response = self.generate_institution_response(response_type)
        
        # Run deliberation
        deliberation = CommunityDeliberation(
            model=self,
            event=event,
            institution_response=institution_response
        )
        
        outcomes = deliberation.run()
        
        return outcomes