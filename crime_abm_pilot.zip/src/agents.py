"""
Agent classes
"""

import random
from mesa import Agent
from configs.personas import (
    INDIVIDUALIST_PERSONA_SHORT,
    COLLECTIVIST_PERSONA_SHORT
)
from src.utils import llm_call, logger

class CommunityAgent(Agent):
    """Base agent class"""
    
    def __init__(self, unique_id, model, culture):
        super().__init__(unique_id, model)
        
        self.culture = culture  # "individualism" or "collectivism"
        
        # Survey-calibrated parameters (for now, use defaults)
        # Later we'll sample from survey distributions
        if culture == "individualism":
            self.self_censorship = random.uniform(8, 12)  # Low (survey M=10.2)
            self.participation_base = random.uniform(9, 13)  # Low (survey M=11.2)
            self.persona = INDIVIDUALIST_PERSONA_SHORT
        else:  # collectivism
            self.self_censorship = random.uniform(16, 20)  # High (survey M=18.5)
            self.participation_base = random.uniform(14, 18)  # High (survey M=16.3)
            self.persona = COLLECTIVIST_PERSONA_SHORT
        
        # Internal state
        self.private_opinion = None
        self.public_statement = None
        self.attended_deliberation = False
        self.silence_reason = None
        
        logger.info(f"Created Agent {unique_id} ({culture})")
    
    def decide_participation(self, event):
        """Decide whether to attend community meeting"""
        
        if self.culture == "individualism":
            # Low base rate + only if interested
            base_prob = 0.25
        else:  # collectivism
            # High base rate (social obligation)
            base_prob = 0.75
        
        # Simple decision for MVP
        will_attend = random.random() < base_prob
        
        logger.debug(f"Agent {self.unique_id} attendance decision: {will_attend}")
        
        return will_attend
    
    def form_private_opinion(self, event, institution_response):
        """Form private opinion about the event"""
        
        prompt = f"""
{self.persona}

A governance event occurred in your community:
{event['description']}

The institution's response was:
{institution_response}

What is your honest, private thought about this situation?
Think about:
- How does this make you feel?
- What do you think should be done?
- Do you trust the institution's response?

Respond in 2-3 sentences with your TRUE inner thoughts.
"""
        
        self.private_opinion = llm_call(
            prompt=prompt,
            max_tokens=200,
            temperature=0.8
        )
        
        logger.debug(f"Agent {self.unique_id} private opinion: {self.private_opinion[:100]}...")
        
        return self.private_opinion
    
    def decide_to_speak(self, context):
        """Decide whether to speak in the meeting (if attended)"""
        
        if self.culture == "individualism":
            # Individualists speak freely if they attend
            return True
        
        else:  # collectivism
            # Collectivists may self-censor
            
            # Simple heuristic for MVP: higher self-censorship = more likely silent
            silence_prob = self.self_censorship / 25  # 0.64-0.80 range
            
            # Increase silence if institution response was blaming
            if context.get('institution_response_type') == 'blaming':
                silence_prob += 0.2
            
            will_speak = random.random() > silence_prob
            
            if not will_speak:
                self.silence_reason = "Self-censorship due to social cost concerns"
                logger.debug(f"Agent {self.unique_id} chose silence")
            
            return will_speak
    
    def generate_public_statement(self, context):
        """Generate public statement (if decided to speak)"""
        
        prompt = f"""
{self.persona}

Context:
- Event: {context['event']['description']}
- Institution response: {context['institution_response']}
- Your private thought: {self.private_opinion}

You are now in a community meeting. Others are listening.

What do you say publicly?

Remember:
- If you are individualist: speak your mind directly
- If you are collectivist: consider social costs, may soften your message

Respond in 2-3 sentences with what you would ACTUALLY say out loud.
"""
        
        self.public_statement = llm_call(
            prompt=prompt,
            max_tokens=200,
            temperature=0.7
        )
        
        logger.debug(f"Agent {self.unique_id} public statement: {self.public_statement[:100]}...")
        
        return self.public_statement
    
    def to_dict(self):
        """Export agent state"""
        return {
            'id': self.unique_id,
            'culture': self.culture,
            'self_censorship': self.self_censorship,
            'attended': self.attended_deliberation,
            'private_opinion': self.private_opinion,
            'public_statement': self.public_statement,
            'silence_reason': self.silence_reason
        }