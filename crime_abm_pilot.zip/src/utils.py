"""
Utility functions
"""

import os
import json
import logging
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv
from anthropic import Anthropic

# Load environment variables
load_dotenv()

# Setup logging
def setup_logging(log_dir="outputs/logs"):
    """Configure logging"""
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    
    log_file = f"{log_dir}/pilot_{datetime.now():%Y%m%d_%H%M%S}.log"
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )
    
    return logging.getLogger(__name__)

logger = setup_logging()

# Initialize Anthropic client
def get_anthropic_client():
    """Get Anthropic API client"""
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY not found in environment variables")
    return Anthropic(api_key=api_key)

# LLM call wrapper with cost tracking
class CostTracker:
    """Track API costs"""
    
    def __init__(self):
        self.calls = []
        self.total_input_tokens = 0
        self.total_output_tokens = 0
        self.total_cost = 0.0
    
    def log_call(self, input_tokens, output_tokens):
        """Log a single API call"""
        # Claude Sonnet 4 pricing (as of 2024)
        # Input: $3 per million tokens
        # Output: $15 per million tokens
        
        input_cost = (input_tokens / 1_000_000) * 3
        output_cost = (output_tokens / 1_000_000) * 15
        call_cost = input_cost + output_cost
        
        self.calls.append({
            'timestamp': datetime.now().isoformat(),
            'input_tokens': input_tokens,
            'output_tokens': output_tokens,
            'cost': call_cost
        })
        
        self.total_input_tokens += input_tokens
        self.total_output_tokens += output_tokens
        self.total_cost += call_cost
        
        logger.debug(f"API call: {input_tokens} in, {output_tokens} out, ${call_cost:.4f}")
    
    def report(self):
        """Print cost report"""
        print("\n" + "="*60)
        print("💰 API COST REPORT")
        print("="*60)
        print(f"Total calls: {len(self.calls)}")
        print(f"Total input tokens: {self.total_input_tokens:,}")
        print(f"Total output tokens: {self.total_output_tokens:,}")
        print(f"Total cost: ${self.total_cost:.2f}")
        if len(self.calls) > 0:
            print(f"Average cost per call: ${self.total_cost/len(self.calls):.4f}")
        print("="*60)
    
    def save(self, filepath="outputs/logs/cost_tracker.json"):
        """Save cost data"""
        data = {
            'total_calls': len(self.calls),
            'total_cost': self.total_cost,
            'total_input_tokens': self.total_input_tokens,
            'total_output_tokens': self.total_output_tokens,
            'calls': self.calls
        }
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)

# Global cost tracker
cost_tracker = CostTracker()

# LLM call function
def llm_call(prompt, system_prompt=None, max_tokens=1000, temperature=0.7):
    """
    Make a call to Claude API
    
    Args:
        prompt: User message
        system_prompt: System instructions (optional)
        max_tokens: Maximum response length
        temperature: Sampling temperature
    
    Returns:
        str: Model response text
    """
    client = get_anthropic_client()
    
    messages = [{"role": "user", "content": prompt}]
    
    kwargs = {
        "model": "claude-sonnet-4-20250514",
        "max_tokens": max_tokens,
        "temperature": temperature,
        "messages": messages
    }
    
    if system_prompt:
        kwargs["system"] = system_prompt
    
    try:
        response = client.messages.create(**kwargs)
        
        # Track cost
        cost_tracker.log_call(
            input_tokens=response.usage.input_tokens,
            output_tokens=response.usage.output_tokens
        )
        
        # Extract text
        text = response.content[0].text
        
        logger.debug(f"LLM response: {text[:100]}...")
        
        return text
    
    except Exception as e:
        logger.error(f"LLM call failed: {e}")
        raise

# Save JSON helper
def save_json(data, filepath):
    """Save data to JSON file"""
    Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    logger.info(f"Saved: {filepath}")

# Load JSON helper
def load_json(filepath):
    """Load data from JSON file"""
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)