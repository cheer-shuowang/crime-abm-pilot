"""
Community deliberation logic
"""

import numpy as np
from src.utils import logger, save_json
from datetime import datetime

class CommunityDeliberation:
    """Manages community deliberation process"""
    
    def __init__(self, model, event, institution_response):
        self.model = model
        self.event = event
        self.institution_response = institution_response
        self.participants = []
        self.rounds = []
    
    def run(self):
        """Execute full deliberation process"""
        
        logger.info(f"Starting deliberation on: {self.event['type']}")
        
        # Step 1: Decide who attends
        self.select_participants()
        
        # Step 2: Participants form private opinions
        self.form_private_opinions()
        
        # Step 3: Round 1 - Initial statements
        round1 = self.round1_initial_statements()
        self.rounds.append(round1)
        
        # For MVP, stop here (can add more rounds later)
        
        # Step 4: Measure outcomes
        outcomes = self.measure_outcomes()
        
        # Save log
        self.save_log()
        
        return outcomes
    
    def select_participants(self):
        """Determine who attends the meeting"""
        
        for agent in self.model.schedule.agents:
            will_attend = agent.decide_participation(self.event)
            
            if will_attend:
                agent.attended_deliberation = True
                self.participants.append(agent)
        
        logger.info(f"Attendance: {len(self.participants)}/{len(self.model.schedule.agents)}")
    
    def form_private_opinions(self):
        """All participants form private opinions"""
        
        for agent in self.participants:
            agent.form_private_opinion(
                event=self.event,
                institution_response=self.institution_response
            )
    
    def round1_initial_statements(self):
        """Round 1: Agents decide whether to speak"""
        
        statements = []
        
        context = {
            'event': self.event,
            'institution_response': self.institution_response,
            'institution_response_type': self.institution_response.get('type', 'unknown')
        }
        
        for agent in self.participants:
            
            will_speak = agent.decide_to_speak(context)
            
            if will_speak:
                statement = agent.generate_public_statement(context)
                
                statements.append({
                    'agent_id': agent.unique_id,
                    'culture': agent.culture,
                    'text': statement
                })
            else:
                # Agent attended but stayed silent
                statements.append({
                    'agent_id': agent.unique_id,
                    'culture': agent.culture,
                    'text': None,  # Silent
                    'silence_reason': agent.silence_reason
                })
        
        logger.info(f"Round 1: {len([s for s in statements if s['text']])} spoke, "
                   f"{len([s for s in statements if not s['text']])} silent")
        
        return {
            'round': 1,
            'statements': statements
        }
    
    def measure_outcomes(self):
        """Measure deliberation outcomes"""
        
        total_agents = len(self.model.schedule.agents)
        attended = len(self.participants)
        spoke = len([s for s in self.rounds[0]['statements'] if s['text']])
        
        # Core metrics
        attendance_rate = attended / total_agents
        speech_rate = spoke / attended if attended > 0 else 0
        attendance_speech_gap = attendance_rate - speech_rate
        
        # Opinion gaps (calculate for agents who spoke)
        opinion_gaps = []
        for agent in self.participants:
            if agent.public_statement:
                # For MVP, simple heuristic: if collectivist + blaming, likely has gap
                if agent.culture == "collectivism" and \
                   self.institution_response.get('type') == 'blaming':
                    gap = random.uniform(0.6, 0.9)  # Placeholder
                else:
                    gap = random.uniform(0.1, 0.3)  # Placeholder
                opinion_gaps.append(gap)
        
        mean_opinion_gap = np.mean(opinion_gaps) if opinion_gaps else 0
        
        outcomes = {
            'total_agents': total_agents,
            'attended': attended,
            'spoke': spoke,
            'attendance_rate': attendance_rate,
            'speech_rate': speech_rate,
            'attendance_speech_gap': attendance_speech_gap,
            'mean_opinion_gap': mean_opinion_gap
        }
        
        logger.info(f"Outcomes: attend={attendance_rate:.2f}, speak={speech_rate:.2f}, "
                   f"gap={attendance_speech_gap:.2f}")
        
        return outcomes
    
    def save_log(self):
        """Save complete deliberation log"""
        
        log = {
            'timestamp': datetime.now().isoformat(),
            'event': self.event,
            'institution_response': self.institution_response,
            'total_agents': len(self.model.schedule.agents),
            'participants': [p.to_dict() for p in self.participants],
            'rounds': self.rounds,
            'outcomes': self.measure_outcomes()
        }
        
        filename = f"outputs/deliberations/delib_{datetime.now():%Y%m%d_%H%M%S}.json"
        save_json(log, filename)
        
        return log